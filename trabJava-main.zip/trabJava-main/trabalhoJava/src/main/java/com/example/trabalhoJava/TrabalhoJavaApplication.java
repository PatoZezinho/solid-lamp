package com.example.trabalhoJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabalhoJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabalhoJavaApplication.class, args);

	}
}
