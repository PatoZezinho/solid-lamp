package com.example.trabalhoJava.dto;

public record EstoqueRequestDTO(
        String produto,
        int quantidade,
        double preco) {
}
